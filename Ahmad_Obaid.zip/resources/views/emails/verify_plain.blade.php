Your verification code is: {{ $verificationCode }}

Thank you for registering!
