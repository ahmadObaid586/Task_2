<?php

namespace App\Http\Controllers;

use PragmaRX\Google2FAQRCode\Google2FA;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Mail;
use App\Events\UserRegistered;  
use App\Mail\VerifyEmail;
class AuthController extends Controller
{
    public function store(Request $request)
    {
        try {
            
    
            $user = User::create([
                'email' => $request->email,
                'phone_number' => $request->phone_number,
                'username' => $request->username,
                'profile_photo_path' => $request->file('profile_photo_path')->store('profile_photo_path'),
                'certificate_path' => $request->file('certificate_path')->store('certificate_path'),
                'password' => Hash::make($request->password),
                'email_verification_code' => Str::random(6),
            ]);
    
            Mail::to($request->email)->send(new VerifyEmail($user));
    
            $token = $user->createToken('API Token')->plainTextToken;
    
            event(new UserRegistered($user));
    
            return response()->json([
                'message' => 'Registration successful! Please check your email to verify your account.',
                'verification_code' => $user->email_verification_code,
                'token' => $token,  
            ], 201);
    
        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Registration failed. Please try again later.',
                'details' => $e->getMessage(),
            ], 500);
        }
    }    
    


public function verifyEmail(Request $request)
    {
        $request->validate([
            'email' => 'required|email|exists:users',
            'verification_code' => 'required'
        ]);

        $user = User::where('email', $request->email)
                    ->where('email_verification_code', $request->verification_code)
                    ->first();

        if (!$user || Carbon::parse($user->created_at)->addMinutes(10)->isPast()) {
            return response()->json(['message' => 'Invalid or expired verification code.'], 400);
        }

        $user->email_verified_at = now();
        $user->email_verification_code = null;
        $user->save();

        return response()->json(['message' => 'Email verified successfully!']);
    }



    public function login(Request $request)
{
    $request->validate([
        'login' => 'required',
        'password' => 'required',
    ]);

    try {
        $loginField = filter_var($request->login, FILTER_VALIDATE_EMAIL) ? 'email' : 'phone_number';

        $user = User::where($loginField, $request->login)->first();

        if ($user && Hash::check($request->password, $user->password)) {
            $token = $user->createToken('API Token')->plainTextToken;

            return response()->json([
                'message' => 'Login successful!',
                'token' => $token, 
                'user' => $user
            ], 200);
        }

        return response()->json(['message' => 'Invalid login credentials.'], 401);

    } catch (\Exception $e) {
        return response()->json(['error' => 'Something went wrong', 'details' => $e->getMessage()], 500);
    }
}

   
 public function logout(Request $request)
{
    $request->user()->currentAccessToken()->delete();
    return response()->json(['message' => 'Logged out successfully.'], 200);
}



public function enable2FA(Request $request)
{
    $user = $request->user();

    $google2fa = new Google2FA();
    $secretKey = $google2fa->generateSecretKey();

    $user->two_factor_secret = encrypt($secretKey);
    $user->save();

    $QRCodeUrl = $google2fa->getQRCodeInline(
        'YourAppName',
        $user->email,
        $secretKey
    );

    return response()->json(['message' => '2FA enabled successfully.', 'qrcode' => $QRCodeUrl]);
}

public function refreshToken(Request $request)
{
    $user = $request->user();
    $user->tokens()->delete();

    $token = $user->createToken('API Token')->plainTextToken;

    return response()->json(['token' => $token], 200);
}


}

