<?php

namespace App\Listeners;

use App\Events\UserRegistered;
use App\Mail\VerifyEmail;
use Illuminate\Support\Facades\Mail;

class SendVerificationEmail
{
    /**
     * Handle the event.
     *
     * @param  \App\Events\UserRegistered  $event
     * @return void
     */
    public function handle(UserRegistered $event)
    {
        // إرسال البريد الإلكتروني للتحقق
        Mail::to($event->user->email)->send(new VerifyEmail($event->user));
    }
}
