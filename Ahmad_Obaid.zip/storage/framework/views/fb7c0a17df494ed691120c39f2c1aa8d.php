Your verification code is: <?php echo e($verificationCode); ?>


Thank you for registering!
<?php /**PATH E:\wamp64\www\final\resources\views/emails/verify_plain.blade.php ENDPATH**/ ?>